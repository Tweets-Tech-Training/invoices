<?php

namespace Database\Seeders;

use App\Models\Link;
use Illuminate\Database\Seeder;

class LinksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $link = Link::create([
            'title'=>'Users',
            'route'=>'',
            'parent_id'=>0,
            'show_in_menu'=>1,
        ]);
        Link::create([
            'title'=>'عرض المستخدمين',
            'route'=>'user',
            'parent_id'=>$link->id,
            'show_in_menu'=>1,

        ]);

        Link::create([
            'title'=>'اضافة مستخدم جديد ',
            'route'=>'user.create',
            'parent_id'=>$link->id,
            'show_in_menu'=>0,
        ]);
        Link::create([
            'title'=>'تعديل المستخدمين',
            'route'=>'user.edit',
            'parent_id'=>$link->id,
            'show_in_menu'=>0,
        ]);
        //ادارة فواتير المبيعات
        $link = Link::create([
            'title'=>'فواتير المبيعات',
            'route'=>'',
            'parent_id'=>0,
            'show_in_menu'=>1,
        ]);
        Link::create([
            'title'=>'عرض الفواتير',
            'route'=>'bill',
            'parent_id'=>$link->id,
            'show_in_menu'=>1,

        ]);

        Link::create([
            'title'=>'اضافة فاتورة جديدة ',
            'route'=>'bill.create',
            'parent_id'=>$link->id,
            'show_in_menu'=>0,
        ]);
        Link::create([
            'title'=>'تعديل فاتورة',
            'route'=>'bill.edit',
            'parent_id'=>$link->id,
            'show_in_menu'=>0,
        ]);


        //ادارة فواتير المصروفات
        $link = Link::create([
            'title'=>'فواتير المصروفات',
            'route'=>'',
            'parent_id'=>0,
            'show_in_menu'=>1,
        ]);
        Link::create([
            'title'=>'عرض فواتير المصروفات',
            'route'=>'billExpenses',
            'parent_id'=>$link->id,
            'show_in_menu'=>1,

        ]);

        Link::create([
            'title'=>'اضافة فاتورة جديدة ',
            'route'=>'billExpenses.create',
            'parent_id'=>$link->id,
            'show_in_menu'=>0,
        ]);
        Link::create([
            'title'=>'تعديل فاتورة',
            'route'=>'billExpenses.edit',
            'parent_id'=>$link->id,
            'show_in_menu'=>0,
        ]);

        //ادراة الزبائن
        $link = Link::create([
            'title'=>' الزبائن',
            'route'=>'',
            'parent_id'=>0,
            'show_in_menu'=>1,
        ]);
        Link::create([
            'title'=>'عرض الزبائن ',
            'route'=>'customer',
            'action_name'=>'customer_show',
            'parent_id'=>$link->id,
            'show_in_menu'=>1,

        ]);

        Link::create([
            'title'=>'اضافة زبون ',
            'route'=>'billExpenses.create',
            'parent_id'=>$link->id,
            'show_in_menu'=>0,
        ]);
        Link::create([
            'title'=>'تعديل فاتورة',
            'route'=>'billExpenses.edit',
            'parent_id'=>$link->id,
            'show_in_menu'=>0,
        ]);

    }
}


<div class="navbar-header">
    <ul class="nav navbar-nav flex-row">
        <li class="nav-item mr-auto"><a class="navbar-brand" href="#">
                <div class="brand-logo"></div>
                <h2 class="brand-text mb-0">تويتس تك</h2>
            </a></li>
        <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary" data-ticon="icon-disc"></i></a></li>
    </ul>
</div>

<div class="shadow-bottom"></div>
<div class="main-menu-content">
    <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
        <li class=" nav-item"><a href="{{route('Maindashboard')}}"><i class="feather icon-home"></i><span class="menu-title" data-i18n="Dashboard">الرئيسية</span></a>

        </li>

        <li class=" nav-item"><a href="{{route('city')}}"><i class="feather icon-image"></i><span class="menu-title" data-i18n="Dashboard">المحافظات</span></a>

        </li>
        <li class=" nav-item"><a href="{{route('coin')}}"><i class="feather icon-credit-card"></i><span class="menu-title" data-i18n="Dashboard">العملات</span></a>

        </li>


        </li>
        <li class=" nav-item"><a href="{{route('user')}}"><i class="feather icon-user"></i><span class="menu-title" data-i18n="Dashboard"> المستخدمين </span></a>

        </li>

        <li class=" nav-item"><a href="{{route('customer')}}"><i class="feather icon-users"></i><span class="menu-title" data-i18n="Dashboard">الزبائن</span></a>
        <li class=" nav-item"><a href="{{route('expensesCategory')}}"><i class="feather icon-cast"></i><span class="menu-title" data-i18n="Dashboard">اصناف المصروفات</span></a>
        <li class=" nav-item"><a href="{{route('billExpenses')}}"><i class="feather icon-credit-card"></i><span class="menu-title" data-i18n="Dashboard">فواتير المصروفات </span></a>

        </li>

        <li class=" nav-item"><a href="{{route('category')}}"><i class="feather icon-message-square"></i><span class="menu-title" data-i18n="Dashboard"> اصناف المبيعات</span></a>

   <li class=" nav-item"><a href="{{route('bill')}}"> <i class="feather icon-server"></i> <span class="menu-title " data-i18n="Dashboard">فواتير المبيعات  </span></a>





    </ul>
</div>

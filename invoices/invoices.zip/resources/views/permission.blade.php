@extends('dashboard_layout.main')
@section('content')

    <div class=" col-md-12">
        <div class="card">
            <div class="card-body">
                <form class="form" action="{{route('user.postPermission',$user->id)}}" method="post" >
                    @csrf
                    @method('post')
                <div class="row">
                    <div class="top">
                        <strong class="col-12 d-flex flex-sm-row flex-column justify-content-between mt-1"> تعديل صلاحيات المستخدم {{$user->name}}  </strong>
                    <br>
                    </div>
                    <div class="table-responsive">
                    <div class="col-12">

{{--        <div class="table-responsive">--}}
{{--            <table class="table table-hover">--}}
{{--                <thead>--}}
{{--                <tr>--}}
{{--                    <th scope="col">#الاسم</th>--}}
{{--                    <th scope="col">اضافة</th>--}}
{{--                    <th scope="col">عرض</th>--}}
{{--                    <th scope="col">تعديل</th>--}}
{{--                    <th scope="col">حذف</th>--}}
{{--                </tr>--}}
{{--                </thead>--}}
{{--                <tbody>--}}
{{--                    <tr>--}}
{{--                        <th >  <label> <b> ادارة المستخدمين </b></label></th>--}}

{{--                            <td><div class="mb-3 form-check"><input   type='checkbox' name='links[]' value=''>--}}
{{--                                </div></td>--}}
{{--                        <td><div class="mb-3 form-check"><input   type='checkbox' name='links[]' value=''>--}}
{{--                            </div></td>--}}
{{--                        <td><div class="mb-3 form-check"><input   type='checkbox' name='links[]' value=''>--}}
{{--                            </div></td>--}}
{{--                        <td><div class="mb-3 form-check"><input   type='checkbox' name='links[]' value=''>--}}
{{--                            </div></td>--}}

{{--                    </tr>--}}
{{--                    <tr>--}}
{{--                        <th >  <label> <b> ادارة المستخدمين </b></label></th>--}}

{{--                        <td><div class="mb-3 form-check"><input   type='checkbox' name='links[]' value=''>--}}
{{--                            </div></td>--}}
{{--                        <td><div class="mb-3 form-check"><input   type='checkbox' name='links[]' value=''>--}}
{{--                            </div></td>--}}
{{--                        <td><div class="mb-3 form-check"><input   type='checkbox' name='links[]' value=''>--}}
{{--                            </div></td>--}}
{{--                        <td><div class="mb-3 form-check"><input   type='checkbox' name='links[]' value=''>--}}
{{--                            </div></td>--}}

{{--                    </tr>--}}

{{--                </tbody>--}}

{{--            </table>--}}
{{--        </div>--}}
                <table class="table data-thumb-view dataTable no-footer dt-checkboxes-select" id="DataTables_Table_0" role="grid">
                    <thead>
                    <tr role="row">

                        <th rowspan="1" colspan="1">
                            الاسم
                        </th>

                        <th rowspan="1" colspan="1">
                            اضافة
                        </th>

                        <th rowspan="1" colspan="1">
                            عرض
                        </th>
                        <th rowspan="1" colspan="1">
                            تعديل
                        </th>



                    </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td> ادراة المستخدمين </td>
                            <td>  <input   type='checkbox'></td>
                            <td>  <input   type='checkbox'></td>
                            <td> <input   type='checkbox'></td>

                        </tr>
                        <tr>
                            <td> ادراة فواتير المصروفات  </td>
                            <td>  <input   type='checkbox'></td>
                            <td>  <input   type='checkbox'></td>
                            <td> <input   type='checkbox'></td>

                        </tr>
                        <tr>
                            <td> ادراة فواتير المبيعات </td>
                            <td>  <input   type='checkbox'></td>
                            <td>  <input   type='checkbox'></td>
                            <td> <input   type='checkbox'></td>

                        </tr>
                        <tr>
                            <td> اضافة محافظات    </td>
                            <td>  <input   type='checkbox'></td>
                            <td>  <input   type='checkbox'></td>
                            <td> <input   type='checkbox'></td>

                        </tr>

{{--                    @empty--}}
{{--                        <div class='alert alert-info mt-4'>لا يوجد عناصر لعرضها </div>--}}
{{--                    @endforelse--}}
                    </tbody>
                </table>

                    </div>
                    </div>
{{--                <div class="col-12 d-flex flex-sm-row flex-column justify-content-end mt-1" >--}}
{{--                <a href='' class="btn btn-primary mr-auto" type="reset">Cancel </a>--}}
{{--                <button  class="btn btn-warning " >Save</button>--}}
{{--        </div>--}}

                    <div class="col-12 d-flex flex-sm-row flex-column justify-content-end mt-1" >
                        <div class="form-group">
                            <a href='{{route("user")}}' class="btn btn-danger  mr-1 mb-1" type="reset"><i class="glyphicon glyphicon-repeat"></i> إلغاء </a>

                            <button type="submit"  class="btn btn-success  mr-1 mb-1" >حفظ</button>

                        </div>
                    </div>

            </div>
                </form>
            </div>
        </div>
    </div>
@endsection

<div class="row" id="getOrder">
    <hr>
    <div class="form-group col-md-4">
        <label for="category">الاصناف</label>
        <?php if(isset($categories)): ?>

                        <select  class="ddlStatus  form-control"  wire:model="priceArray.category_id" name="category_id" id="category_id">

            <option value="">اختر الصنف  </option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        <?php endif; ?>
        <?php $__errorArgs = ['bill.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="form-group col-md-4">
        <label> الكمية  </label>
        <input type="text"   wire:model="bill.amount"  name="amount" class="form-control" >
    </div>

    <div class="form-group col-md-4">
        <label> السعر للوحدة   </label>
        <input type="text"   wire:model="bill.categoryprice" name="categoryprice"  class="form-control" >
    </div>
    <div class="form-group col-md-4">
        <label>اجمالي السعر    </label>
        <input type="text" disabled  wire:model="bill.unitprice" name="unitprice" class="form-control" >
    </div>
    <div class="form-group col-md-4">
        <br>



    </div>


</div>
<?php /**PATH C:\Users\HP\Desktop\TweetsTech\Invoices\invoices\resources\views/livewire/bill/order.blade.php ENDPATH**/ ?>
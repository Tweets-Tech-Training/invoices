<div>
    <style>

        .form-group.required .form-label:after {
            content:"*";
            color:red;
            font-size: 18px;
            /*font-family: 'Glyphicons Halflings';*/
            font-weight: normal;
        }
    </style>
    <div class="card">
        <div class="card-content">
            <div class="card-body">
                        <h4 class="d-none d-sm-block">
                            <?php if($customer->id): ?>
                            <span> تعديل الزبون </span>
                            <?php else: ?>
                                <span> اضافة الزبون </span>
                            <?php endif; ?>
                        </h4>
                        <br>
                        <form  id="sampleForm" >



                         <div class="row">

                            <div class=" form-group col-md-5 required">

                                <label  class="form-label">الاسم </label>
                                <input type="text"  wire:model="customer.name" id="name" name="name" class="form-control" >
                                <?php $__errorArgs = ['customer.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group col-md-5 required">
                                <label for="inputEmail4" class="form-label">   الايميل </label>
                                <input type="email"   wire:model="customer.email"  class="form-control" >
                                <?php $__errorArgs = ['customer.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            </div>

                        <div class="row">
                            <div class="form-group col-md-5 required">
                                <label for="category" class="form-label">المدينة</label>
                                <?php if(isset($cities)): ?>
                                    <select  class="ddlStatus  form-control"  wire:model="customer.city_id" name="city_id" id="city_id">
                                        <option value="">اختر مدينة </option>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                <?php endif; ?>
                                <?php $__errorArgs = ['customer.city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>


                            <div class=" form-group col-md-5 required">
                                <label for="inputAddress4" class="form-label">العنوان بالتفصيل</label>
                                <input type="text"   wire:model="customer.address" name="address" id="address" class="form-control" >
                                <?php $__errorArgs = ['customer.address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                            </div>
                        </div>
                        <div class="row">
                            <div class=" form-group col-md-5 required">
                                <label for="inputAddress4" class="form-label">رقم الجوال</label>
                                <input type="number"  wire:model="customer.mobile" id="mobile" class="form-control" name="mobile" >
                                <?php $__errorArgs = ['customer.mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-sm-5">








                            </div>
                        </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <br>
                                    <button type="button" wire:click.prevent="save" class="btn btn-success" >حفظ</button>
                                    <a href='<?php echo e(route("customer")); ?>' class="btn btn-outline-default round mr-1 mb-1" type="reset"><i class="glyphicon glyphicon-repeat"></i> إلغاء </a>

                                </div>
                            </div>
                    </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\HP\Desktop\TweetsTech\Invoices\invoices\resources\views/livewire/customer/form.blade.php ENDPATH**/ ?>
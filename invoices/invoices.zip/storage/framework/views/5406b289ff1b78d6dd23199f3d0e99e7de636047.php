<nav class="header-navbar navbar-expand-lg navbar navbar-with-menu floating-nav navbar-light navbar-shadow">
    <div class="navbar-wrapper">
    <div class="navbar-container content">
    <div class="navbar-collapse" id="navbar-mobile">
    <div class="mr-auto float-left bookmark-wrapper d-flex align-items-center">
    <ul class="nav navbar-nav">
    <li class="nav-item mobile-menu d-xl-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ficon feather icon-menu"></i></a></li>
    </ul>
        <!-- Begin: sub  Menu of  favourite,,email ....etc -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- End: sub  Menu of  favourite,,email ....etc -->
    </div>

    <ul class="nav navbar-nav float-right">

        <!-- Begin: Main Menu- change language-->
    
    
    
        <!-- End: Main Menu- change language-->
        <!-- Begin: Main Menu- user zoom screen-->
    <li class="nav-item d-none d-lg-block"><a class="nav-link nav-link-expand"><i class="ficon feather icon-maximize"></i></a></li>
        <!-- End: Main Menu- user zoom screen-->

        <!-- Begin: Main Menu- user search-->
     
    
    
    
    
    
    
        
    
        <!-- End: Main Menu- user search-->
        <!-- Begin: Main Menu- user chart-->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
        <!-- Begin: Main Menu- user chart-->
        <!-- Begin: Main Menu- user notification-->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

        <!-- End: Main Menu- user notification-->
        <!-- Begin: Main Menu- user profile-->
    <li class="dropdown dropdown-user nav-item"><a class="dropdown-toggle nav-link dropdown-user-link" href="javascript:;" data-toggle="dropdown">
    <div class="user-nav d-sm-flex d-none"><span class="user-name text-bold-600"> <?php echo e(Auth::user()->name); ?></span></div>
            <?php if(Auth::user()->image): ?>
                <span><img class="round" src="<?php echo e(asset('storage/images/'.Auth::user()->image)); ?>" alt="avatar" height="40" width="40"></span>

            <?php else: ?>
                <span><img class="round" src="<?php echo e(asset('admin-layout/app-assets/images/portrait/small/avatar-s-11.jpg')); ?>" alt="avatar" height="40" width="40"></span>

            <?php endif; ?>
        </a>
    <div class="dropdown-menu dropdown-menu-right">



        <a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><i class="feather icon-user"></i> البيانات الشخصية</a>


    <div class="dropdown-divider"></div><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
            <i class="feather icon-power"></i> تسجيل الخروج</a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
    </li>
        <!-- End: Main Menu- user profile-->
    </ul>
    </div>
    </div>
    </div>
</nav>

<!-- Begin: sub  Menu of search result-->

    
            
        
    
            
                
                
                    
                
            
        
    
            
                
                
                    
                
            
        
    
            
                
                
                    
                
            
        
    
            
                
                
                    
                
            
        
    
            
        
    
            
                
                
                    
                
            
        
    
            
                
                
                    
                
            
        
    
            
                
                
                    
                
            
        
    
            
                
                
                    
                
            
        


    
            
        


<!-- End: sub  Menu Menu of search result-->
<?php /**PATH C:\Users\HP\Desktop\TweetsTech\Invoices\invoices\resources\views/dashboard_layout/horizontal-menu.blade.php ENDPATH**/ ?>
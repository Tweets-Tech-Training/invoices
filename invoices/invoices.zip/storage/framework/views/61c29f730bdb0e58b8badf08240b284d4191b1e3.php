<?php $__env->startSection('content'); ?>

    <div class=" col-md-12">
        <div class="card">
            <div class="card-body">
                <form class="form" action="<?php echo e(route('user.postPermission',$user->id)); ?>" method="post" >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
                <div class="row">
                    <div class="top">
                        <strong class="col-12 d-flex flex-sm-row flex-column justify-content-between mt-1"> تعديل صلاحيات المستخدم <?php echo e($user->name); ?>  </strong>
                    <br>
                    </div>
                    <div class="table-responsive">
                    <div class="col-12">












































                <table class="table data-thumb-view dataTable no-footer dt-checkboxes-select" id="DataTables_Table_0" role="grid">
                    <thead>
                    <tr role="row">

                        <th rowspan="1" colspan="1">
                            الاسم
                        </th>

                        <th rowspan="1" colspan="1">
                            اضافة
                        </th>

                        <th rowspan="1" colspan="1">
                            عرض
                        </th>
                        <th rowspan="1" colspan="1">
                            تعديل
                        </th>



                    </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td> ادراة المستخدمين </td>
                            <td>  <input   type='checkbox'></td>
                            <td>  <input   type='checkbox'></td>
                            <td> <input   type='checkbox'></td>

                        </tr>
                        <tr>
                            <td> ادراة فواتير المصروفات  </td>
                            <td>  <input   type='checkbox'></td>
                            <td>  <input   type='checkbox'></td>
                            <td> <input   type='checkbox'></td>

                        </tr>
                        <tr>
                            <td> ادراة فواتير المبيعات </td>
                            <td>  <input   type='checkbox'></td>
                            <td>  <input   type='checkbox'></td>
                            <td> <input   type='checkbox'></td>

                        </tr>
                        <tr>
                            <td> اضافة محافظات    </td>
                            <td>  <input   type='checkbox'></td>
                            <td>  <input   type='checkbox'></td>
                            <td> <input   type='checkbox'></td>

                        </tr>




                    </tbody>
                </table>

                    </div>
                    </div>





                    <div class="col-12 d-flex flex-sm-row flex-column justify-content-end mt-1" >
                        <div class="form-group">
                            <a href='<?php echo e(route("user")); ?>' class="btn btn-danger  mr-1 mb-1" type="reset"><i class="glyphicon glyphicon-repeat"></i> إلغاء </a>

                            <button type="submit"  class="btn btn-success  mr-1 mb-1" >حفظ</button>

                        </div>
                    </div>

            </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard_layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\TweetsTech\Invoices\invoices\resources\views/permission.blade.php ENDPATH**/ ?>

                        <table class="table data-thumb-view dataTable no-footer dt-checkboxes-select" id="DataTables_Table_0" role="grid">
                            <thead>
                            <tr role="row">

                                <th rowspan="1" colspan="1">
                                    الرقم
                                </th>

                                <th rowspan="1" colspan="1">
                                    اسم الزبون
                                </th>
                                <th rowspan="1" colspan="1">
                                    الحالة
                                </th>
                                <th rowspan="1" colspan="1">
                                    المبلغ المطلوب
                                </th>
                                <th rowspan="1" colspan="1">
                                    رقم الزبون
                                </th>


                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($bill->id); ?></td>
                                    <td><?php echo e($bill->customers?->name); ?></td>
                                    <td><?php echo e($bill->status == "recived"?'مستلمة':'غير مستلمة'); ?></td>
                                    <td><?php echo e($bill->result); ?></td>
                                    <td><?php echo e($bill->customers?->mobile); ?></td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>








<?php /**PATH C:\Users\HP\Desktop\TweetsTech\Invoices\invoices\resources\views/livewire/bill/excel.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div>


<div class=" col-md-12">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-start align-items-center mb-1">

                <div class="col-12 d-flex flex-sm-row flex-column justify-content-between mt-1">
                    <p>   <span class="font-weight-bold ">رقم الفاتورة: الفاتورة    <?php echo e($bill->id); ?></span> <br>
                    <span class="font-weight-bold">اسم الزبون</span> <span><?php echo e($bill->customers?->name); ?></span> <br>
                <span class="font-weight-bold ">   رقم الزبون  :</span> <?php echo e($bill->customers?->mobile); ?> </p>

                    <p>
                        <span class="font-weight-bold ">تاريخ الفاتورة:</span>
                        <span class="font-small-2"><?php echo e($bill->created_at); ?></span><br>
                 <span class="font-weight-bold ">  حالة الفاتورة  :</span><?php echo e($bill->status == "recived"?'مسددة':'غير مسددة'); ?> <br>
                    <span class="font-weight-bold">  المبلغ المطلوب:</span> <span style="color: #0C9A9A">   <?php echo e($bill->result); ?></span> </p>


                </div>

                <div class="ml-auto user-like text-danger">

                </div>
            </div>

            <div class="row">
                <div class="col-md-4">







            </div>


            


            <table class="table table-hover">
                <thead>
                <tr>
                    <th scope="col">الصنف</th>
                    <th scope="col">الكمية</th>
                    <th scope="col">سعر الوحدة </th>
                    <th scope="col">اجمالي السعر </th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $bill->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->categories?->name); ?></td>
                        <td><?php echo e($order->amount); ?></td>
                        <td><?php echo e($order->categoryprice); ?></td>
                        <td><?php echo e($order->unitprice); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>



        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard_layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\TweetsTech\Invoices\invoices\resources\views/show.blade.php ENDPATH**/ ?>
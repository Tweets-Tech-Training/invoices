<div>

    <style>

        hr {
            width: 100%;
            border-top: 1px solid rgba(45, 41, 47, 0.3);
        }
        .form-group.required .form-label:after {
            content:"*";
            color:red;
            font-size: 18px;
            /*font-family: 'Glyphicons Halflings';*/
            font-weight: normal;
        }
    </style>

<div class="container">

        <div class="row">



                <div class="card ">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="col-md-12">
                                <?php if($bill->id): ?>
                                    <h5> تعديل الفواتير  </h5>
                                <?php else: ?>
                                <h5> اضافة فاتورة  </h5>
                                <?php endif; ?>
                            </div>
                            <br>
                            <div class="row">
                            <div class="col-12 col-md-9">
                            <div class="row">

                                <div class=" form-group col-md-8 required " >
                                    <div wire:ignore >
                                        <label  class="form-label">الاسم </label>
                                        <?php if(isset($customers)): ?>
                                            <select  class="ddlStatus  form-control"  wire:model="bill.customer_id" name="customer_id" id="customer_id">
                                                <option value="">اختر اسم الزبون </option>
                                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        <?php endif; ?></div>

                                    <?php $__errorArgs = ['bill.customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group col-md-4">
                                    <br>

                                    <a type="button" class="btn btn-outline-primary waves-effect waves-light"  href="<?php echo e(route('customer.create')); ?>" >اضافة زبون جديد <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus align-middle"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg></a>

                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-md-4 required " >
                                    <div wire:ignore>
                                        <label class="form-label">المحافظة</label>
                                        <?php if(isset($citites)): ?>
                                            <select  class="form-control select-cities"  wire:model="bill.city_id" name="city_id" id="select2">
                                                <option value="">اختر المحافظة </option>
                                                <?php $__currentLoopData = $citites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        <?php endif; ?></div>

                                    <?php $__errorArgs = ['bill.city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                </div>
                                <div class="form-group col-md-4 required " >
                                    <div wire:ignore>
                                        <label class="form-label">العملات</label>
                                        <?php if(isset($coins)): ?>
                                            <select  class=" form-control"  wire:model="bill.coin_id" name="coin_id" id="coin_id" >
                                                <option value="">اختر العملة </option>
                                                <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  value="<?php echo e($coin->id); ?>"><?php echo e($coin->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>

                                        <?php endif; ?></div>

                                    <?php $__errorArgs = ['bill.coin_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                                </div>

                                <div class="form-group col-md-4 required">
                                    <label class="form-label">حالة الزبون ( مسلم  ام غير مسلم )</label>
                                    <select class="form-select form-control"   wire:model="bill.customerstatus" aria-label="Default select example" name="customerstatus"
                                            id="customerstatus">
                                        <option value="">حالة الزبون </option>

                                        <option <?php echo e(old('customerstatus')=='recived'? 'selected': ''); ?> value="recived">مسلم</option>
                                        <option <?php echo e(old('customerstatus')=='unrecived'? 'selected': ''); ?> value="unrecived"> غير مسلم </option>


                                    </select>
                                    <?php $__errorArgs = ['bill.customerstatus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>




                            </div>
                            <div class="row">
                                <div class="col-md-4 ">
                                    <div class="form-group required">
                                        <label class="form-label">   الحالة
                                        </label>
                                        <select class="form-select form-control"   wire:model="bill.status" aria-label="Default select example" name="status"
                                                id="status">
                                            <option value="">حالة الفاتورة (مسددة ام لا )</option>

                                            <option <?php echo e(old('status')=='recived'? 'selected': ''); ?> value="recived">مسددة</option>
                                            <option <?php echo e(old('status')=='unrecived'? 'selected': ''); ?> value="unrecived"> غير مسددة </option>


                                        </select>
                                        <?php $__errorArgs = ['bill.status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>

                                <?php if($bill->status =="recived"): ?>
                                <div class="col-md-4">
                                    <div class="form-group">

                                        <label for="gender">طريقة الدفع
                                        </label>
                                        <select class="form-select form-control"    wire:model="bill.payment" aria-label="Default select example" name="payment"
                                                id="payment">
                                            <option value="">اختر طريقة الدفع</option>

                                            <option <?php echo e(old('payment')=='money_transfer'? 'selected': ''); ?> value="money_transfer">حوالة</option>
                                            <option <?php echo e(old('payment')=='check'? 'selected': ''); ?> value="check">شيك   </option>
                                            <option <?php echo e(old('payment')=='cash'? 'selected': ''); ?> value="cash">نقدا   </option>


                                        </select>
                                        <?php $__errorArgs = ['bill.payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                </div>
                                <?php endif; ?>
                                <div class="col-md-4">
                                    <div class="form-group required">
                                        <label class="form-label">مرتبطة بقيد مالي
                                        </label>
                                        <select class="form-select form-control"    wire:model="bill.related" aria-label="Default select example" name="related"
                                                id="related">
                                            <option value="">مرتبطة بقيد مالي ام لا </option>

                                            <option <?php echo e(old('related')=='1'? 'selected': ''); ?> value="1">مرتبطة بقيد مالي</option>
                                            <option <?php echo e(old('related')=='0'? 'selected': ''); ?> value="0">غير مرتبطة بقيد مالي    </option>
                                        </select>
                                        <?php $__errorArgs = ['bill.related'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                </div>
                            </div>

                                <div class="row">
                                    <div class="col-md-4">


                                        <?php if($bill->payment =="check" || $bill->payment =="money_transfer"): ?>

                                                <div class="form-group" >
                                                    <label for="name">التاريخ  :</label>
                                                    <input type="date" wire:model="bill.date" class="form-control" name="date" id="date">
                                                    <?php $__errorArgs = ['bill.date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                        <?php endif; ?>
                                    </div>



                                </div>


                                <?php

                                $total=0;
                                ?>
                                <?php $__currentLoopData = $priceArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php

                                    $priceArray[$index]['unitprice']=(float) $priceArray[$index]['amount'] * (float) $priceArray[$index]['categoryprice'];
                                        $total += $priceArray[$index]['unitprice'];

                                    ?>
                                <div class="row" >
                                        <hr>
                                    <div class="form-group col-md-4">
                                        <label for="category">الاصناف</label>
                                        <?php if(isset($categories)): ?>
                                            <select  class="ddlStatus  form-control"  wire:model="priceArray.<?php echo e($index); ?>.category_id" name="category_id" id="category_id">
                                                <option value="">اختر الصنف  </option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>

                                        <?php endif; ?>

                                        <?php $__errorArgs = ["priceArray.$index.category_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                    </div>


                                    <div class="form-group col-md-4">
                                        <label> الكمية  </label>
                                        <input type="text"   wire:model="priceArray.<?php echo e($index); ?>.amount"  name="amount" class="form-control" >
                                        <?php $__errorArgs = ["priceArray.$index.amount"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label> السعر للوحدة   </label>
                                        <input type="text"   wire:model="priceArray.<?php echo e($index); ?>.categoryprice" name="categoryprice"  class="form-control" >
                                        <?php $__errorArgs = ["priceArray.$index.categoryprice"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label>اجمالي السعر    </label>
                                        <input type="text" disabled   value="<?php echo e($priceArray[$index]['unitprice']); ?>" name="unitprice" class="form-control" >
                                    </div>

                                    <div class="form-group col-md-4">
                                        <br>

                                      <?php if($index==0): ?>
                                        <button        wire:click="addRow"
                                                       class="btn btn-outline-primary mr-1 mb-1 waves-effect waves-light"><i class="feather icon-plus-circle"></i>
                                            اضافة صنف  جديد                                 </button>
                                          <?php endif; ?>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <hr>

                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label> مجموع الاصناف    </label>
                                        <input type="text"  disabled value="<?php echo e($total); ?> "name="totalprice" class="form-control" >
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label> الضريبة   </label>
                                        <input type="text"   wire:model="tax" name="tax"  class="form-control" >
                                        <?php $__errorArgs = ['bill.tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php
                                    $result= $tax * $total;
                                    ?>
                                    <div class="form-group col-md-4">
                                        <label> المبلغ المطلوب (النهائي)  </label>
                                        <input disabled type="text"  value="<?php echo e($result); ?>"  name="result"  class="form-control" >
                                    </div>

                              </div>
                            </div>

                           <div class="col-12 col-md-3">


    
    <div class="row">


        <div class="col-md-5 ">
            <h5>اختر صورة </h5>
            <div class="upload-btn-wrapper mx-auto">
                <div class="upload-btn">
                    <?php if($image): ?>

                        <img src="<?php echo e($image->temporaryUrl()); ?>"  style="border: 3px solid #D3D3D3; border-radius: 15px; width:100%; height: 100%  ">
                    <?php else: ?>
                        <?php if($bill): ?>
                            <img style="border: 3px solid #D3D3D3; border-radius: 15px; width: 100%; height: 100%" src="<?php echo e($bill->image?asset('storage/images/'.$bill->image):asset('storage/images/no-image.png')); ?>">

                        <?php endif; ?>
                    <?php endif; ?>



                </div>
                <input type="file" class="form-control" wire:click wire:model="image" name="image" id="image">
                <?php $__errorArgs = ['bill.image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
        </div>


    </div>

    



</div>
                                <div class="col-12 d-flex flex-sm-row flex-column justify-content-end mt-1" >
                                    <div class="form-group">
                                        <a href='<?php echo e(route("bill")); ?>' class="btn btn-danger  mr-1 mb-1" type="reset"><i class="glyphicon glyphicon-repeat"></i> إلغاء </a>

                                        <button type="button" wire:click.prevent="save" class="btn btn-success  mr-1 mb-1" >حفظ</button>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>





</div>
</div>
<?php $__env->startPush('script'); ?>
    <script>





        $(document).ready(function() {
            $('#select2').select2();
            $('#select2').on('change', function (e) {
                var data = $('#select2').select2("val");
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('bill.city_id', e.target.value);
            });
        });



        $(document).ready(function() {
            $('#customer_id').select2();
            $('#customer_id').on('change', function (e) {
                var data = $('#customer_id').select2("val");
                   window.livewire.find('<?php echo e($_instance->id); ?>').set('bill.customer_id', e.target.value);
            });
        });
        $(document).ready(function() {
            $('#coin_id').select2();
            $('#coin_id').on('change', function (e) {
                var data = $('#coin_id').select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set('bill.coin_id', e.target.value);
            });
        });

    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\Users\HP\Desktop\TweetsTech\Invoices\invoices\resources\views/livewire/bill/form.blade.php ENDPATH**/ ?>
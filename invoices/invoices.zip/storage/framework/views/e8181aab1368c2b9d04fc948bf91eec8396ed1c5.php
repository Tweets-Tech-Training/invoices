<?php $__env->startSection('title','Create Post'); ?>
<?php $__env->startSection('content'); ?>
<div>


<div class="col-lg-6 col-12">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-start align-items-center mb-1">
                <div class="avatar mr-1">
                    <img src="https://tasks.tweet.ps/storage/images/PuTl6SNhqx3RE7oWeIhUsOyLlXtkJRruYM5KnnYK.png" alt="avtar img holder" height="90" width="90">
                </div>
                <div class="user-page-info">
                    <p class="mb-0">فاتورة</p>
                    <p>
                        <span class="font-weight-bold">تاريخ التقرير:</span>
                        <span class="font-small-2">2021-09-25 16:02:17</span>
                    </p>
                </div>
                <div class="ml-auto user-like text-danger">
                    <a   class="btn-edit action-trash a-style danger">
                        <i class="feather icon-trash"></i>
                    </a>

                    <a href="" class="btn-edit action-edit a-style warning">
                        <i class="feather icon-edit"></i>
                    </a>

                </div>
            </div>
            <div>
                <p class="font-weight-bold"> <span>عدد ساعات العمل:</span> <span>7:0</span></p>
            </div>
            <div>

                <p class="font-weight-bold"><span> نوع ساعات العمل:</span> <span style="color: #0C9A9A"> ساعات الدوام الصباحية</span> </p>
            </div>

            <p class="font-weight-bold">النقاط المنجزة:</p>
            <ul style="list-style: decimal">
                <li class="mb-1">عمل التعديلات المطلوبة في الفاتورة </li>
                <li class="mb-1">make profile for the user </li>
                <li class="mb-1">تحديث صفحة الاحصائيات للفواتير</li>
            </ul>




        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\HP\Desktop\TweetsTech\Invoices\invoices\resources\views/livewire/show.blade.php ENDPATH**/ ?>